package stepDefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class StepDefinition {

	
	private static final String BaseUrl = "http://deckofcardsapi.com";
	private static String deckId = null;
	private static String responseString = null;
	private static Response response;
	private static RequestSpecification req;
	
	@Given("^user is making a get request$")
	public void makeGetRequest() {
		RestAssured.baseURI = BaseUrl;
		req = RestAssured.given();
		response = req.get("/api/deck/new");
		responseString = response.asString();
		System.out.println(responseString);
		deckId = JsonPath.from(responseString).get("deck_id");
		System.out.println(deckId);
		
	}
	
	@Given("^user is making get request with jokers$")
	public void makeGetReqwithJoker() {
		RestAssured.baseURI = BaseUrl;
		req = RestAssured.given();
		response = req.queryParam("jokers_enabled", true).get("/api/deck/new");
		System.out.println(response.asString());
	}
	
	@When("^user is drawing card using deck id$")
	public void drawCard() {
		RestAssured.baseURI = BaseUrl;
		req = RestAssured.given();
		response = req.get("/api/deck/" + deckId + "/draw");
		System.out.println(response.asString());
	}
}
